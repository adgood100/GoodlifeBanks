<script>
$(document).ready(function(){
    $("#signInModal").click(function(){
        $("#signInModal").modal();
    });
});
</script>