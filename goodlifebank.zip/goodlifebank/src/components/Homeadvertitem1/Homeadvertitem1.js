import React from "react";

const Homeadvertitem1 = () =>

	<div className="advert-item-holder advert-1">
		<div className="advert-item-inner">
			<div className="advert-item-image"></div>
			<div className="advert-item-blurb">
				<h4 className="m-t-0 m-b-1">
					Verify unusual activity
				</h4>
				<p className="m-b-0">
					Alerts let you verify unusual purchases right from the App
				</p>
			</div>
		</div>
	</div>;

export default Homeadvertitem1;