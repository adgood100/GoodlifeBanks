import React from "react";

const Productcategory2 = () =>

	<div className="category-item" id="category-cash-rewards">
		<a href="#" className="d-block">
			<div className="category-image">
				<div className="img-holder m-x-auto">
					<img className="img-item" src="assets/images/product-category-2.png"/>
				</div>
			</div>
			<div className="category-title">
				<span>Cash Rewards</span>
			</div>
		</a>
	</div>;

export default Productcategory2;	