import React from "react";

const Homeadvertitem2 = () =>

	<div className="advert-item-holder advert-2">
		<div className="advert-item-inner">
			<div className="advert-item-image"></div>
			<div className="advert-item-blurb">
				<h4 className="m-t-0 m-b-1">
					New to Innovate Financial Services?
				</h4>
				<p className="m-b-0">
					Let us introduce you to our banking solutions
				</p>
			</div>
		</div>
	</div>;

export default Homeadvertitem2;