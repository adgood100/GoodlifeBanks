import React from "react";

const Homeadvertitem4 = () =>

	<div className="advert-item-holder advert-4">
		<div className="advert-item-inner">
			<div className="advert-item-image"></div>
			<div className="advert-item-blurb">
				<h4 className="m-t-0 m-b-1">
					Bank Smarter
				</h4>
				<p className="m-b-0">
					Our improved mobile and online banking features put you control
				</p>
			</div>
		</div>
	</div>;

export default Homeadvertitem4;
