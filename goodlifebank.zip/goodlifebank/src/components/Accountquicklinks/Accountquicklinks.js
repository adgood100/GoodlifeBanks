import React from "react";

const Accountquicklinks = () => 

	<div className="p-a-2 backgrounded-whited">
		<div className="headline m-b-1">
			<h4>Quick Links</h4>
		</div>
		<ul className="chevroned-list list-unstyled m-b-0">
			<li><a href="#">Make a payment</a></li>
			<li><a href="#">Track payments</a></li>
			<li><a href="#">View statements</a></li>
			<li><a href="#">Manage transfers and direct debits</a></li>
			<li><a href="#">Make a transfer</a></li>
		</ul>
	</div>;

export default Accountquicklinks;