module.exports = {
  Customer: require("./Customer"),
  Accounts: require("./Accounts"),
  Transactions: require("Transactions")
};